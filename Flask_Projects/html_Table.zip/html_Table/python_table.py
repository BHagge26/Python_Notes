StudentTable = [
    {
        "first_name" : "branden",
        "last_name" : "hagge"
    },
    {
        "first_name" : "Jason",
        "last_name" : "Durillo"
    },
    {
        "first_name" : "paul",
        "last_name" : "mcCartney"
    },
    {
        "first_name" : "alex",
        "last_name" : "becker"
    },
    
    {
        'first_name' : 'Chris',
        'last_name' : 'Tucker'
    },
    
    {
        'first_name' : 'Cerveja', 
        'last_name' : 'Sculpin IPA'
    },
    
    {
        'first_name' : 'David',
        'last_name' : 'Bolsenaro'
    },
    
    {
        'first_name' : 'Jack',
        'last_name' : 'Skellington'
    }
]



